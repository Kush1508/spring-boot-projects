package com.cognizant.online_training_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineTrainingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineTrainingAppApplication.class, args);
	}

}
