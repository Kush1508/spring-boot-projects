package com.cognizant.online_training_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineTrainingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
